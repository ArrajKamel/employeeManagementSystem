package main;

public class Employee extends User{
}
