package main;

public class HR extends User {
}
