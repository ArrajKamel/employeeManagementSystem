package main;

public class User {
    public  int id = 0;
    public String firstname ;
    public String lastname ;
    public String gender;
    public String phone ;
    public String position;
    public int salary ;
    public int isEmployee;
    public String username ;
    public String password ;

}
